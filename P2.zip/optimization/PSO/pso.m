clc;
clear;
close all;

%% Problem Definition
CostFunction = @(x) Obj(x);        % Your objective function that accepts [Kp, Ki, Gain]
nVar = 3;                         % Number of decision variables: Kp, Ki, Gain
VarSize = [1 nVar];               % Size of decision variable vector

% Define individual lower and upper bounds for each parameter
VarMin = [0.1, 0.01, 1];    % Example lower bounds for [Kp, Ki, Gain]
VarMax = [10, 1, 100];      % Example upper bounds for [Kp, Ki, Gain]

%% PSO Parameters
MaxIt = 1000;                % Maximum number of iterations
nPop = 100;                  % Population size (number of particles)

% PSO coefficients
w = 1;                      % Inertia weight
wdamp = 0.99;               % Inertia weight damping ratio
c1 = 1.5;                   % Personal learning coefficient
c2 = 2.0;                   % Global learning coefficient

% Velocity Limits (element-wise)
VelMax = 0.1 * (VarMax - VarMin);
VelMin = -VelMax;

%% Initialization
empty_particle.Position = [];
empty_particle.Cost = [];
empty_particle.Velocity = [];
empty_particle.Best.Position = [];
empty_particle.Best.Cost = [];

particle = repmat(empty_particle, nPop, 1);
GlobalBest.Cost = inf;

for i = 1:nPop
    
    % Initialize Position (each variable within its bounds)
    particle(i).Position = unifrnd(VarMin, VarMax, VarSize);
    
    % Initialize Velocity (zeros)
    particle(i).Velocity = zeros(VarSize);
    
    % Calculate Cost
    particle(i).Cost = CostFunction(particle(i).Position);
    
    % Initialize Personal Best
    particle(i).Best.Position = particle(i).Position;
    particle(i).Best.Cost = particle(i).Cost;
    
    % Update Global Best
    if particle(i).Best.Cost < GlobalBest.Cost
        GlobalBest = particle(i).Best;
    end
end

BestCost = zeros(MaxIt,1);

%% PSO Main Loop
for it = 1:MaxIt
    
    for i = 1:nPop
        
        % Update Velocity
        particle(i).Velocity = w * particle(i).Velocity ...
            + c1 * rand(VarSize) .* (particle(i).Best.Position - particle(i).Position) ...
            + c2 * rand(VarSize) .* (GlobalBest.Position - particle(i).Position);
        
        % Apply Velocity Limits element-wise
        particle(i).Velocity = max(particle(i).Velocity, VelMin);
        particle(i).Velocity = min(particle(i).Velocity, VelMax);
        
        % Update Position
        particle(i).Position = particle(i).Position + particle(i).Velocity;
        
        % Velocity Mirror Effect
        IsOutside = (particle(i).Position < VarMin) | (particle(i).Position > VarMax);
        particle(i).Velocity(IsOutside) = -particle(i).Velocity(IsOutside);
        
        % Apply Position Limits element-wise
        particle(i).Position = max(particle(i).Position, VarMin);
        particle(i).Position = min(particle(i).Position, VarMax);
        
        % Calculate Cost
        particle(i).Cost = CostFunction(particle(i).Position);
        
        % Update Personal Best
        if particle(i).Cost < particle(i).Best.Cost
            particle(i).Best.Position = particle(i).Position;
            particle(i).Best.Cost = particle(i).Cost;
            
            % Update Global Best
            if particle(i).Best.Cost < GlobalBest.Cost
                GlobalBest = particle(i).Best;
            end
        end
    end
    
    BestCost(it) = GlobalBest.Cost;
    
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    
    % Dampen inertia weight
    w = w * wdamp;
end

BestSol = GlobalBest;

%% Results
figure;
semilogy(BestCost, 'LineWidth', 2);
xlabel('Iteration');
ylabel('Best Cost');
grid on;

disp(['Optimized Kp: ', num2str(BestSol.Position(1))]);
disp(['Optimized Ki: ', num2str(BestSol.Position(2))]);
disp(['Optimized Gain: ', num2str(BestSol.Position(3))]);
