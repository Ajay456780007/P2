% Lagrange Multiplier-based OPF Fitness Function
function cost = lagrange_opf_cost_function(gen_output, mpc)
    % Update generator outputs in MATPOWER case
    mpc.gen(:, 2) = gen_output;  % Generator outputs
    
    % Step 1: Power balance (equality constraint)
    lambda = 1; % Lagrange multiplier for power balance constraint (initial guess)
    
    % Active power load P_L is in the 3rd column of mpc.bus matrix
    P_L = sum(mpc.bus(:, 3));  % Total active power demand
    
    % Active power generation P_G is the sum of all generator outputs
    P_G = sum(mpc.gen(:, 2));  % Total active power generation
    
    % Power balance error
    power_balance_error = P_G - P_L;  % Difference between generation and load
    
    % Step 2: Generator limits (inequality constraints)
    mu = min(0, mpc.gen(:, 10) - gen_output);  % Lagrange multipliers for lower limit violations
    nu = max(0, gen_output - mpc.gen(:, 9)); % Lagrange multipliers for upper limit violations
    
    % Step 3: Voltage limits (inequality constraints)
    voltage_error = 0; % Assume voltage error is negligible in this example
    
    % Step 4: Lagrange-based objective function (including penalties for constraint violations)
    penalty_factor = 1e4;
    penalty = penalty_factor * (power_balance_error^2 + sum(mu) + sum(nu) + voltage_error);
    
    % Run OPF using MATPOWER to get the generation cost
    results = runopf(mpc);  % Solve OPF using MATPOWER
    
    % Objective is to minimize the generation cost + penalties from constraint violations
    cost = -1*sum(results.f + penalty); % Total cost + penalties
    
end
