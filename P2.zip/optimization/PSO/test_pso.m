function [Best_generation]=test_pso(MaxIt, nPop, mpc)
    CostFunction=@(x) lagrange_opf_cost_function(x, mpc);        % Cost Function
    
    nVar=length(mpc.gen(:,1));  % Number of generators;            % Number of Decision Variables
    
    VarSize=[1 nVar];   % Size of Decision Variables Matrix
    
    % VarMin=-10;         % Lower Bound of Variables
    % VarMax= 10;         % Upper Bound of Variables
    
    VarMax = max(mpc.gen(:, 9));  % Minimum generation limits
    VarMin = min(mpc.gen(:, 10)); % Maximum generation limits
    %% PSO Parameters
    % 
    % MaxIt=MaxIt;      % Maximum Number of Iterations
    % 
    % nPop=npop;        % Population Size (Swarm Size)

    [Best_sol]=PSO_Optimization(CostFunction, nVar, VarSize,VarMin,  VarMax,MaxIt, nPop );
    Best_generation = Best_sol.Position;

end