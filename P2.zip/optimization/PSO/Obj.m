function J = Obj(x)
    % x(1) = Kp, x(2) = Ki, x(3) = Gain
    
    % Assign parameters to MATLAB workspace
    assignin('base', 'Kp', x(1));
    assignin('base', 'Ki', x(2));
    assignin('base', 'Gain', x(3));
    
    % Run Simulink model programmatically
    simOut = sim('se_filter_base1', 'StopTime', '2.5', 'SaveOutput', 'on', 'ReturnWorkspaceOutputs', 'on');
    
    % Extract simulation logs
    logsout = simOut.logsout;
    
    try
        % Extract voltage and current signals by their logged names
        voltage_signal = logsout.getElement('Voltage_thd_signal').Values.Data;
        current_signal = logsout.getElement('Current_thd_signal').Values.Data;
       
        Fs =50;
   
        thd_voltage = thd(voltage_signal, Fs);
        thd_current = thd(current_signal, Fs);

        J = thd_voltage + thd_current;
        
    catch
        % In case of error (e.g., missing signals), assign a large penalty cost
        J = 1e6;
    end
end
