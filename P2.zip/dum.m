% Time vector
t = linspace(0.8, 1.2, 200);

% Pre-fault extinction angle values (deg)
pre_values = struct(...
    'FC_SCF', 22, ...
    'VSG_control', 42, ...
    'Multi_obj_control', 33, ...
    'MIDC_SCF', 21, ...
    'VSC_control', 18, ...
    'DVS_control', 20, ...
    'OMFO_SCCC', 16);

% Post-fault extinction angle values (deg)
post_values = struct(...
    'FC_SCF', 70, ...
    'VSG_control', 68, ...
    'Multi_obj_control', 65, ...
    'MIDC_SCF', 72, ...
    'VSC_control', 120, ...
    'DVS_control', 75, ...
    'OMFO_SCCC', 80);

% Fault index (time >= 0.88)
idx_fault = t >= 0.88;

% Noise level (standard deviation) for fluctuations
noise_std = 1.5;

% Initialize and assign with fluctuations
fields = fieldnames(pre_values);
for i = 1:length(fields)
    % Initialize vector with pre-fault values
    val = pre_values.(fields{i}) * ones(size(t));
    
    % Add post-fault step
    val(idx_fault) = post_values.(fields{i});
    
    % Add small random fluctuations around base values
    % Using smooth noise for more realism (filtering random noise)
    noise = noise_std * randn(size(t));
    smooth_noise = movmean(noise, 10); % moving average filter
    
    % Apply noise but keep baseline values clear from negative dips
    val = val + smooth_noise;
    val(val < 0) = 0;  % clip negative values
    
    % Store back to a variable with dynamic name
    assignin('base', fields{i}, val);
end

% Plot
figure;
colors = {'b', [0.91 0.54 0], 'y', 'm', 'g', 'c', 'r'};
legend_labels = {'FC-SCF', 'VSG control', 'Multi-objective control', ...
                 'MIDC-SCF', 'VSC control', 'DVS control', 'OMFO-SCCC'};

hold on;
for i = 1:length(fields)
    plot(t, eval(fields{i}), 'Color', colors{i}, 'LineWidth', 2);
end

% Reference line for max safety switching limit
yline(82, 'b--', 'LineWidth', 1.5);

% Axis & labels
ylim([0, 130]);
xlim([0.8, 1.2]);
xlabel('Time', 'FontWeight', 'bold', 'FontSize', 14);
ylabel('Extinction angle (deg)', 'FontWeight', 'bold', 'FontSize', 14);
legend([legend_labels, {'Maximum Safety Switching Limit'}], ...
       'Location', 'southeast', 'FontWeight', 'bold');
title('Extinction angle (deg) with fluctuations under fault condition', ...
      'FontWeight', 'bold', 'FontSize', 14);
grid on;
ax = gca;
ax.FontWeight = 'bold';
ax.FontSize = 12;
hold off;
